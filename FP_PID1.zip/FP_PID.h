//FP_PID.h
// header file for a fast Motor control PID class using Fixed Point arithmetic
// optimised for a fixed loop frequency of 8192hz
//
// Input, Output and setpoint are 16-bit signed values
//
// Pterm: 
//		accepts a float and converts to a 16-bit integer value in the z-domain
// Iterm:
//		accepts a float and converts to a 16:16 Fixed Point value in the z-domain
// Dterm:
//		accepts a float and converts to a 16:16 Fixed Point value in the z-domain
// 
// larger integer values should be unnecessary and will cause overflow errors!!!
//
//
// Author: J Holland
// Date: 25th October 2020
// Version: 0.1


#ifndef PID_h
#define PID_h


class FP_PID
{
	public: 
		FP_PID( int* Input, int* Output, int* Setpoint, float Pterm, float Iterm, float Dterm, unsigned int LoopFreq);
		void SetOutputLimits(int MaxOutput, int MinOutput);
		void SetIntegralLimits(int IMax, int Imin);
		void Compute();
		void SetParams(float Pterm, float Iterm, float Dterm, unsigned int LoopFreq);

   //debug routines
   long GetTmpPz();
   long GetTmpIz();
   long GetTmpDz();
   long GetTmpCalcMon();
   long GetError();
  
  
	private:
		unsigned long kp_z;                  // * Proportional gain in Z-Domain
		unsigned long ki_z;                  // * Integral gain in Z-Domain
		unsigned long kd_z;                  // * Derivative gain in Z-Domain

   //debug
    long tmpCalcMon;                  // debug only
    long tmpError;                  // debug only
		long tmpPz;
    long tmpIz;
    long tmpDz;
   // end debug
    
		int* myInput;              // Use pointers to variables to avoid the overhead  
		int* myOutput;             // of having to the data
		int* mySetpoint;          
 							   
		
    long ILimitMax;
    long ILimitMin;
    int OutLimitMax;
    int OutLimitMin;
		int lastInput;
    long isum;
};	

	
#endif
