#ifndef __ETC_H__
#define __ETC_H__

  #define PIDTICK 4    // the tick for the PID controller - every 4 PWM periods @ 3921Hz = 
  
  
  int motorSpeed;
  unsigned int motorCurrent;
  int loopCount;
  unsigned long PIDLoopCount;       
  
  bool serialOutStatus;


  //PID constants
  byte Kp=5, Ki=1, Kd=0, Hz=4900;
  byte output_bits = 8;
  bool output_signed = false;

  int iFeedback = A1;
  int TOV1_MONITOR = 12;


#endif
