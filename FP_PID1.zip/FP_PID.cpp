/* FP_PID.cpp
 *  fast PID implementation using fixed point arithmetic
 *  this implemention is for a loop time of 8192Hz only
 *  
 *  Input, Setpoint and Output are 16-bit signed Integer values
 *  
 * Pterm: 
 *    accepts float and is converted to 16:16 fixed point notation
 * Iterm: 
 *    accepts float and is converted to 16:16 fixed point notation
 * Dterm: 
 *    accepts float and is converted to 16:16 fixed point notation
 *    
 *    Note: larger integer terms should not be necessary and will cause an overflow
 *    
 * Author:  James Holland 
 * Date:    25th October 2020
 * Version  0.1
 *  
 */
#include "FP_PID.h"

/*Constructor (...)*********************************************************
 *    The parameters specified here are those for for which we can't set up
 *    reliable defaults, so we need to have the user set them.
 ***************************************************************************/
FP_PID::FP_PID(int* PID_Input, int* PID_Output, int* PID_Setpoint, float Pterm, float Iterm, float Dterm, unsigned int LoopFreq)
{
  myInput = PID_Input;
  myOutput = PID_Output;
  mySetpoint = PID_Setpoint;
  
  SetParams(Pterm, Iterm, Dterm, LoopFreq);
}



void FP_PID::Compute()
{

    long input = *myInput;
    long error = *mySetpoint - input;
	  long DValue = input - lastInput;
	  long tempCalc;
    int tempOut;
    unsigned char polTest;
    

    tmpError = error;
    tmpPz = kp_z * error;
    tmpDz = kd_z * DValue;
    

	//calculate ITerm  
   isum += (ki_z* error);
   // windup prevention
   if(isum > ILimitMax){isum = ILimitMax; }
   if(isum < ILimitMin){ isum = ILimitMin; }
   
   tempCalc += ((kp_z * error) + isum - (kd_z * DValue));

// !!!!!! need to test the negative case !!!!!!!!!!
   tempOut = (int)(tempCalc >> 16);			// shift back from FP to integer

   
   if(tempOut > OutLimitMax){ tempOut=OutLimitMax; }
   if(tempOut < OutLimitMin){ tempOut=OutLimitMin; }

   *myOutput = tempOut;

}


void FP_PID::SetParams(float Pterm, float Iterm, float Dterm, unsigned int Freq)
{
  kp_z = (unsigned long)(65535 * Pterm);
  ki_z = (unsigned long)((65535 * Iterm)/Freq);
  kd_z = (unsigned long)(65535 * Dterm);

  isum = 0;         // reset integrator
  lastInput = 0;    // assume we always start at zero

//set default parameters
  SetOutputLimits(1024, -1024);
  SetIntegralLimits(100, -100);
}

void FP_PID::SetOutputLimits(int MaxOutput, int MinOutput)
{
  OutLimitMax = MaxOutput;
  OutLimitMin = MinOutput;
}


void FP_PID::SetIntegralLimits(int IMax, int IMin)
{
  ILimitMax = (65535 * IMax);
  ILimitMin = (65535 * IMin);
}
  

/* Status Funcions*************************************************************
 * These functions allow access to the internal state of the PID. 
 * They are intended for debug purposes
 ******************************************************************************/
long FP_PID::GetTmpPz(){ return  tmpPz; }
long FP_PID::GetTmpIz(){ return  isum;}
long FP_PID::GetTmpDz(){ return  tmpDz;}
long  FP_PID::GetTmpCalcMon(){ return  tmpCalcMon;}
long FP_PID::GetError(){ return tmpError;}
